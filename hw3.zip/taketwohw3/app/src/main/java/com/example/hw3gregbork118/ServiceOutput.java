package com.example.hw3gregbork118;

public class ServiceOutput {
    ServiceOutput() {}
    public boolean moved;
}
